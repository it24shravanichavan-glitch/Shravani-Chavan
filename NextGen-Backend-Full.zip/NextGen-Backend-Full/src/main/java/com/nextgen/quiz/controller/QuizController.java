
package com.nextgen.quiz.controller;

import com.nextgen.quiz.entity.Quiz;
import com.nextgen.quiz.repository.QuizRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/quizzes")
public class QuizController {

    private final QuizRepository quizRepository;

    public QuizController(QuizRepository quizRepository) {
        this.quizRepository = quizRepository;
    }

    @GetMapping
    public List<Quiz> list() {
        return quizRepository.findAll();
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Quiz quiz) {
        return ResponseEntity.ok(quizRepository.save(quiz));
    }
}
