
package com.nextgen.quiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NextgenBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(NextgenBackendApplication.class, args);
    }
}
