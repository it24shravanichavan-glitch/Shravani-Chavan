NextGen Backend (JWT-enabled)

Run steps:
1. Ensure MySQL running and user 'Shau' with password 'root' can create DB or create DB 'nextgen_quiz' manually.
2. Build: mvn clean install
3. Run: mvn spring-boot:run

APIs:
- POST /api/auth/register  {username,password,role?}
- POST /api/auth/login     {username,password} -> returns {token}
- GET  /api/quizzes
- POST /api/quizzes        (requires auth)
